package com.example.Lab07

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun mySchedule(view: View){
        var intent  = Intent(this,Confirm::class.java)

        intent.putExtra("name", name.text.toString())
        intent.putExtra("addreess", address.text.toString())
        intent.putExtra("city", city.text.toString())
        intent.putExtra("state", destine.text.toString())
        intent.putExtra("zipCode", postCode.text.toString())
        intent.putExtra("Country", country.text.toString())
        startActivity(intent)
    }
}