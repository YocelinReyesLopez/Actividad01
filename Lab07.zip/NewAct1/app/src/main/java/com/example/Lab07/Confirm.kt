package com.example.Lab07

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_confirm.*

class Confirm : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirm)
        snameId.text = intent.getStringExtra("name")
        sAddress.text = intent.getStringExtra("addreess")
        sCity.text = intent.getStringExtra("city")
        sPostal.text = intent.getStringExtra("zipCode")
        sState.text = intent.getStringExtra("state")
        sCountry.text = intent.getStringExtra("Country")
    }
    fun Accept(view: View){
        var agree = Intent(this, ThankYou::class.java)
        startActivity(agree)
    }
    fun Edit(view:View){
        onBackPressed()
    }
}